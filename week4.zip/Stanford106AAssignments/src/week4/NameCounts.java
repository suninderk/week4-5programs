package week4;

import acm.program.ConsoleProgram;
import acmx.export.java.util.*;
public class NameCounts extends ConsoleProgram {
	
	public void run() {
		HashMap nameMap = new HashMap();
		 
		 readNames(nameMap);
		 printMap(nameMap);
		 }
		 private void readNames(HashMap map) {
			 while (true) {
				 String name = readLine("Enter name: ");
				 if (name.equals("")) break;
				 Integer count = (Integer)map.get(name);
				 if (count == null) {
					 count = new Integer(1);
				 } 
				 else {
					 count = new Integer(count + 1);
					 }
				 map.put(name, count);
				 }
			 }
private void printMap(Map map) {
	Iterator it = map.keySet().iterator();
	while (it.hasNext()) {
		String key = (String)it.next();
		int count = (int)map.get(key);
		println("Entry [" + key + "] has count " + count);
		 }
		 }

	}
	

