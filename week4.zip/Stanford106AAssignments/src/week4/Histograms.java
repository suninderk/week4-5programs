package week4;

import acm.program.ConsoleProgram;
//import acmx.*;
import java.io.*;
import acm.util.*;

public class Histograms extends ConsoleProgram {
	public void run() {
		BufferedReader rd;
		
		int[] histArr = new int[11];
		for (int i=0; i<11;i++) {
			histArr[i]=0;
		//}
	}
	//public void readScore(){
		try {
			rd= new BufferedReader(new FileReader("MidtermScores.txt"));
			while (true) {
			String line= rd.readLine();
				if( line==null)
					break;
			System.out.println(rd.readLine());
			int score=Integer.parseInt(line);
			
				if(score<0 || score>100) {
					throw new ErrorException("Number is either <0 or >100");
					}
				else {
			int number=score/10;
			histArr[number]++;
					
				}	
			}	
		}
		catch (IOException e) {
	System.out.println("invalid");
			}
	
		for (int num=0;num<11;num++) {
			String label;
			switch(num){
				case 0:label ="00-09";break;
				case 10:label=" 100";break;
			default:
				label = (10* num)+ "-"+(10*num+9);break;
				}
			
				String stars = "";
				for (int i=0; i<histArr[num];i++) {
					stars+="*";
			println(label + ":" +stars);
				//println(label + ":" );
			
			}	
		}			
	}
	}
	


	/*private BufferedReader rd;
	int a=0, b=0,c=0,d=0,e=0,f=0,g=0,h=0,i=0,j=0,k=0;
	private static final String abc= "MidtermScores.txt";
	public void run() {
		
		try {
			BufferedReader rd = new BufferedReader(new FileReader(abc));
			System.out.println(readLine());
			
			while (true) {
			String line = rd.readLine();
		if(line==null) {
			break;}		
		int score=Integer.parseInt(line);

		if (score >=0 && score< 10) {
			a+=1;	 
		 }
		if (score >=10 &&score<20) {
			b+=1;
		 }
		if (score >=20 &&score<30) {
			c+=1;
		 }
		if (score >=30 &&score<40) {
			d+=1; 
		 }
		 if (score >=40 &&score<50) {
			 e+=1; 
		 }
		 if (score >=50 &&score<10) {
			 f+=1; 
		 }
		 if (score >=60 &&score<10) {
			 g+=1; 
		 }
		 if (score >=70 &&score<10) {
			 h+=1; 
		 }
		 if (score >=80 &&score<10) {
			 i+=1; 
		 }
		 if (score >=90 &&score<100) {
			 j+=1; 
		 } 
		 if (score ==100) {
			 k+=1; 
		 }
		 else {
			System.out.println("number is not between 0 and 100"); 
		 }
		System.out.println("0-9= "+a+"10-19= "+b+"20-29= "+c+"30-39= "+d+"40-49= "+e+"50-59= "+f+"60-69= "+g+"70-79= "+h+"80-89= "+i+"90-99= "+j+"100= "+k);
		}
				}
				catch (IOException e) {
				throw new ErrorException(e);
				}
	
			try {
			rd.close();
			}
			 catch (IOException e) {
			
			e.printStackTrace();
			 }
			}
			}
	
	*/

